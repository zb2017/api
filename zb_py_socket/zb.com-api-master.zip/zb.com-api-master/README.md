# zb.com-api
zb.com api

A simple demo for zb.com .Just some useful functions.
      any question contact sunxuanzhi@lingdianzn.com
